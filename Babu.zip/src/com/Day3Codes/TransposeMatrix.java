package com.Day3Codes;

import java.util.Scanner;

public class TransposeMatrix
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter columns");
		int col=sc.nextInt();
		System.out.println("enter rows");
		int rows=sc.nextInt();
		int a[][]=new int[col][rows];
		System.out.println("enter elements");
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<rows;j++)
			{
				 a[i][j]=sc.nextInt();
			}
		}
		System.out.println("before Sorting");
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<rows;j++)
			{
				System.out.println(a[i][j]+ " ");
			}
			System.out.println();
		}
		
        toarray(a,col,rows);
}

   private static void toarray(int[][]a,int col,int rows)
   {
	   
       int a1[][]=new int[col][rows];
	   for(int i=0;i<col;i++)
	   {
		   for(int j=0;j<rows;j++)
		   {
			 a1[j][i]=a[i][j];
		   }
	   }
	   System.out.println("after transpose");
	   
	   for(int i=0;i<col;i++)
	   {
		   for(int j=0;j<rows;j++)
		   {
			   System.out.println(a1[i][j]+ " ");
		   }
		   System.out.println();
	   }
   }
}

