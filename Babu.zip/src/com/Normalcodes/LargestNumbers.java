package com.Normalcodes;

public class LargestNumbers {

	public static void main(String[] args) {
		int a=4,b=34,c=23;
		if(a>b)
	     System.out.println("a is greatest");
		else if(b>c)
			System.out.println("b is greatest");
		else
			System.out.println("both are equal");

	}

}
