package com.Normalcodes;

import java.util.Scanner;

public class ArmStrong {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		int rem=0,sum=0;
		int num=n;
		int count=String.valueOf(n).length();
		sum=sum+(int)Math.pow(n, count);
		if(num==sum)
		  System.out.println("arm");
	  else
		  System.out.println("not armstrong");

	}

}
