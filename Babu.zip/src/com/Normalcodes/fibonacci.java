package com.Normalcodes;

public class fibonacci {

	public static void main(String[] args) {
		int a=0,b=1,c;
		int n=5;
		System.out.print(a+","+b+",");
		for(int i=0;i<=n;i++) {
		c=a+b;
		a=b;
		b=c;
		if(i==0)
		System.out.print(a);
		else
			System.out.print(","+a);
	
		
		
		}
	}

}
