package com.Normalcodes;

public class LeapOrnotLeap 
{
	public static void main(String[] args)
	{
		int year=2027;
		if(year%400==0)
			System.out.println("leap year");
		else if(year%4==0&&year%100!=0)
			System.out.println("leap year");
		else
			System.out.println("not");
		
	}

}
