package com.Normalcodes;
public class BingoGame {
    public static void main(String[] args) {
        // Check if two arguments are provided
        if (args.length != 2) {
            System.out.println("Please provide exactly two numbers as command-line arguments.");
            return;
        }
 
        // Parse the input numbers
        int num1 = Integer.parseInt(args[0]);
        int num2 = Integer.parseInt(args[1]);
 
        // Validate the input range
        if ((num1 < 1 || num1 > 40) || (num2 < 1 || num2 > 40)) {
            System.out.println("Both numbers must be in the range from 1 to 40.");
            return;
        }
 
        // Initialize the array of integers
        int[] numbersArray = {5, 10, 15, 20, 25}; // Example array
 
        // Check if both numbers are present in the array
        boolean foundNum1 = false;
        boolean foundNum2 = false;
 
        for (int number : numbersArray) {
            if (number == num1) {
                foundNum1 = true;
            }
            if (number == num2) {
                foundNum2 = true;
            }
        }
 
        // Display "Bingo" if both numbers are found
        if (foundNum1 && foundNum2) {
            System.out.println("Bingo!");
        } else {
            System.out.println("Not found.");
        }
    }
}