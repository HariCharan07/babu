package com.Normalcodes;
public class PowerOfNumbers  

{ 
public static void main(String[] args) {   

        int base = 4;   

        int exponent = 2;   

        int result = 1;   

        for (int i = 0; i < exponent; i++) {   

             

            result=result*base; //4  4*4

        }   

        //System.out.println(base + " raised to the power of " + exponent + " is " + result);  

        System.out.println(result); 

    }   

}   