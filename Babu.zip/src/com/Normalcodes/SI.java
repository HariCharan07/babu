package com.Normalcodes;

public class SI {
   public static void main(String[] args) {
	int p=10000,t=12,r=2;
//	double res=(p*t*r)/100;
//	System.out.println(res);
	double amount=0; 

    amount=p*(1+r/100)*t; 
    System.out.println(amount);
}
}
