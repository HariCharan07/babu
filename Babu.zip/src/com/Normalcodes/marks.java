package com.Normalcodes;

import java.util.Scanner;

public class marks
{
	public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter number");
    double n=sc.nextDouble();
    
    if(n>60)
    	System.out.println("grade a");
    else if(n>=45 && n<=60)
    	System.out.println("grade b");
    else if(n>=35 && n<=45)
    	System.out.println("grade c");
    else
    	System.out.println("fail");
    
    
	}

}
