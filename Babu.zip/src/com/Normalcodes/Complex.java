package com.Normalcodes;

import java.util.Scanner;

public class Complex {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter real numbers");
		int m=sc.nextInt();
		int n=sc.nextInt();
		System.out.println("enter imaginary number");
		int k=sc.nextInt();
		int l=sc.nextInt();
		int realres=m+n;
		int imares=k+l;
		System.out.println(realres+" +i"+imares);
		
		
	}

}
