package com.Normalcodes;

public class BoundsExcep
{
	public static void main(String[] args) {
		int a[]= {1,2,34,5,67,2};
		try {
		for(int i=0;i<a.length;i++)
		{
			
		System.out.print(a[8]+" ");
			
			
		}
	
		}
		catch(Exception e)
		{
			System.out.println("your r out range");
		}
	}

}
