package com.Normalcodes;

import java.util.Scanner;

public class fibonacieven
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a=0,b=1,c;
		int result=0;
		if(n==0||n==1)
		{
			System.out.println(a);
		}
		else
		{
		   for(int i=2;i<=n*2;i++)
		   {
		   c=a+b;
		   a=b;
		   b=c;
		     if(i%2==0)
		     {
			  result=result+c;
		     }
			}
		   
		}
		System.out.println(result);
	}

}
