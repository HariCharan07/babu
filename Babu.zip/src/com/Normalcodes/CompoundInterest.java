package com.Normalcodes;
public class CompoundInterest 

{ 

public static void main(String[] args) { 

int p=2,t=4,r=6; 

double amount=0; 

    amount=p*(1+r/100)*t; 

    System.out.println(amount); 

 

 

} 

 

} 