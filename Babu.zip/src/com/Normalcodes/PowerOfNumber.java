package com.Normalcodes;

public class PowerOfNumber
{
	public static void main(String[] args) {
		int base=4;
		int exponent=2;
		int result=1;
		for(int i=0;i<exponent;i++)
		{
			result=result*base;
		}
		System.out.println(result);
	}

}
