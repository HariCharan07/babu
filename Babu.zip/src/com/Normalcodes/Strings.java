package com.Normalcodes;

public class Strings {
public static void main(String[] args) {
	  
	 
	  String str ="sudharsh";
	  
	 StringBuffer br=new StringBuffer(str);
	 System.out.println(br.reverse());
	 System.out.println(str.concat("harshit"));
	 
	  
	
	
}
}
