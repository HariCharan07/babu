package com.Normalcodes;

import java.util.Scanner;

public class PrimeNumbers
{
   public static void main(String[] args) {
	   
	Scanner sc=new Scanner(System.in);
	System.out.println("enter prime numbers from 1 to numbers");
    int n=sc.nextInt();
    int i,count=0;
    for( i=2;i<=n;i++)
    {
    	count=0;
    	for(int j=1;j<=i;j++)
    	{
    		if(i%j==0)
    		count++;
    	}
    
    if(count==2) {
    	System.out.print(i+" ");
    }
    }
}
}
