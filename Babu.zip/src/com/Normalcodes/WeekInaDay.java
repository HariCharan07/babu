package com.Normalcodes;

import java.util.Scanner;

public class WeekInaDay
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int n=sc.nextInt();
		switch(n) 
		{
		case 1:
		System.out.println("sunday");
			//break;
	
		case 2:
		System.out.println("monday");
		//break;
		default:System.out.println("number is not present");
		
		}
	}

}
