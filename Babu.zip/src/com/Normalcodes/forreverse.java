package com.Normalcodes;

public class forreverse {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		
		for(char i='D';i>='A';i--)
		{
			System.out.println(i);
		}

	}

}
