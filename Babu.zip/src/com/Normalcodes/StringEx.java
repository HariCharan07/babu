package com.Normalcodes;

public class StringEx 
{
	public static void main(String[] args) {
		String s="hi";
		StringBuffer s1=new StringBuffer("hi");
		StringBuffer s2=new StringBuffer("hi");
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
	}

}
