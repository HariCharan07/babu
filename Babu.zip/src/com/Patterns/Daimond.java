package com.Patterns;

public class Daimond
{
	public static void main(String[] args) {
		int n=9;
		int s=n/2;
		int letters=1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=s;j++)
			{
				System.out.print(" ");
			}
			for(int j=1;j<=letters;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		
		if(i<=n/2)
		{
			s--;//s=s-1;
			letters=letters+2;
		}
		else
		{
			s++;
			letters=letters-2;
		}
		}
	}

}
