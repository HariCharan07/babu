package com.Patterns;

import java.util.Scanner;

public class SwitchOperators {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two numbers and an operator");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		char operator=sc.next().charAt(0);
		switch(operator) {
		case '+':System.out.println(num1+num2);
		       break;
		case '-':System.out.println(num1-num2);
		       break;
		case '*':System.out.println(num1*num2);
		       break;
		}

	}

}
