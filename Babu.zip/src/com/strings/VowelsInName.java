package com.strings;

public class VowelsInName 
{
	public static void main(String[] args) {
		String s="sudharshan";
		int vowCount=0;
		int consCount=0;
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
			{
				vowCount++;
			}
			else
			{
				consCount++;
			}
		}
		System.out.println(vowCount);
		System.out.println(consCount);
		
	}

}
