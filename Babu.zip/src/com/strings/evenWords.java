package com.strings;

import java.util.Scanner;

public class evenWords 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		even(str);
	}
	public static void even(String s)
	{
		String str1[]=s.split(" ");
		for(String str2:str1)
		{
			if(str2.length()%2==0)
			{
				System.out.println(str2);
			}
		}
	}

}
