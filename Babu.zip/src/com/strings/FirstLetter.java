package com.strings; 

import java.util.Scanner; 

public class FirstLetter { 

public static void main(String[] args) { 

Scanner sc=new Scanner(System.in); 

System.out.println("Enter Sentence :"); 

String string=sc.nextLine(); 

String s[]=string.split(" "); 

String str=""; 

for (int i = 0; i < s.length; i++) { 

str=str+s[i].charAt(0); 

} 

System.out.println(str); 

} 

} 