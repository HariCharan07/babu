package com.strings;

import java.util.Arrays;

public class sortString
{
	public static void main(String[] args) {
		String s="greeksforgreeks";
		char a[]=s.toCharArray();
		Arrays.sort(a);
		//System.out.println(Arrays.toString(a));
		System.out.println(new String(a));
		
		
	}

}
