
package com.strings;

public class insertWordsInString 
{
	public static void main(String[] args) {
		String s="Greek from Greeks";
		String str1="for";
		int index=6;
		String str2=s.substring(0,index)+str1+s.substring(index+4);
		System.out.println(str2);

}
}