package com.strings;

public class countDigits 
{
	public static void main(String[] args) {
		String s="sidd23u";
		int sum=0,num;
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);//
			if(ch>='0'&&ch<='9')
			{
			   num=ch-48;
			   sum=sum+num;//2+3
			}
		}
		System.out.println(sum);
	}

}
