package com.strings;
import java.util.HashSet;

public class PangramChecker 
   {
	 public static void main(String[] args) 
	 {
	        String s = "The quick brown fox 123 jumps over a lazy dog";
	        
	        if (isPangram(s))
	        {
	            System.out.println("The string is a pangram.");
	        } else 
	        {
	            System.out.println("The string is not a pangram.");
	        }
	 }
	
    public static boolean isPangram(String str) {
        str = str.toLowerCase();
       // Use a HashSet to track unique letters
        HashSet<Character> letters = new HashSet<>();
        for (char ch : str.toCharArray()) {
            if (ch >= 'a' && ch <= 'z') {
                letters.add(ch);
            }
        }
        return letters.size() == 26;
    }

    
}
