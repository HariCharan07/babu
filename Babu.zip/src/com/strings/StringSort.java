package com.strings;

import java.util.Scanner;

public class StringSort {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter String :");

		String string = sc.nextLine();

		String s = string.toLowerCase();

		String str = "";

		for (int i = 97; i <= 122; i++) {

			char c = (char) i;

			for (int j = 0; j < s.length(); j++) {

				if (c == s.charAt(j)) {

					str = str + s.charAt(j);
				}
			}
		}
		System.out.println("The Sorted String is");
		System.out.println(str);

	}

}
