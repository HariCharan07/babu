package com.strings;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FirstLetterOfEachWord
{
	public static void main(String[] args) {
		String s1="Greeks for Greeks";
		Pattern p=Pattern.compile("\\b[a-zA-Z]");
		Matcher m1=p.matcher(s1);
		while(m1.find())
		{
			System.out.print(m1.group());
		}
		
		
	}

}
