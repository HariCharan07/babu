package com.strings;
public class changeletterinString {
    
    public static void main(String args[])
    {
       
        String str = "Geeks Gor Geeks";
 
        
        int index = 6;
 
        
        char ch = 'F';
        //String str2="Fog";

        System.out.println("Original String = " + str);
 
        String str1 = str.substring(0, index) +ch+ str.substring(index +1);
 
        // Print the modified string
        System.out.println("Modified String = " + str1);
    }
}