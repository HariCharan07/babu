package com.strings;

import java.util.Scanner;

public class Palindrome 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter String");
		String s=sc.next();
		String s1="";
	
		for(int i=0;i<s.length();i++)
		{
			s1=s.charAt(i)+s1;
			
		}
		if(s.equals(s1))
		{
			System.out.println("palindrome");
		}
		else
			System.out.println("not palindrome");
	}

}
