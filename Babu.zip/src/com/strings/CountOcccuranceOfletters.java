package com.strings;

import java.util.HashMap;

public class CountOcccuranceOfletters {
	public static void main(String[] args)
	{
		String s1="siddui";
		String s2="";
		while(s1.length()>0)
		{
			char ch=s1.charAt(0);
			System.out.println(ch);//s
			s2=s1.replace(ch+"", "");
			System.out.println("s2="+s2);
			int count=s1.length()-s2.length();
			
			System.out.println(ch+"---->"+count);
			s1=s2;
		}
//	HashMap<Character,Integer> m1=new HashMap<>();
//		String s="vamsi";
//		char []s1=s.toCharArray();
//		int[] count=new int[256];
//		for(int i=0;i<s1.length;i++)
//		{
//			m1.put(s1[i], count[s1[i]]++);
//		}
//		for (char c : s1) {
//			System.out.println(count+" "+c);
//		}
	
	}

}
