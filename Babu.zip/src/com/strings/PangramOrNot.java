package com.strings; 

import java.util.Scanner; 

public class PangramOrNot { 

private static String toCheck(String s) { 

for (int i = 97; i <= 122; i++) 
{ 
    char c = (char) i; 
    if (s.contains(c + "") != true) { 
    return "No"; 
    } 
} 
     return "Yes"; 
} 

public static void main(String[] args)
{ 

  Scanner sc = new Scanner(System.in); 

  System.out.println("Enter String :"); 

  String string = sc.nextLine(); 

  String s = string.toLowerCase(); 

  System.out.println(toCheck(s)); 

} 

} 
