package com.strings;

public class FirstCharOfEachWord 
{
	public static void main(String[] args) {
		String s=" hi java world";
		String str[]=s.split(" ");
		for(String str1:str)
		{
			if(str1.length()>0)
			{
				char ch=str1.charAt(0);
				System.out.print(ch);
				//System.out.print(str1.charAt(0));
			}
		}
	}

}
