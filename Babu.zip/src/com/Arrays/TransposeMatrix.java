package com.Arrays; 

import java.util.Scanner; 

public class TransposeMatrix { 

public static void main(String[] args) { 

Scanner sc = new Scanner(System.in); 

System.out.println("Enter No of Columns"); 

int col = sc.nextInt(); 

System.out.println("Enter No of Rows"); 

int row = sc.nextInt(); 

int arr[][] = new int[col][row]; 

System.out.println("Enter Elements"); 

for (int i = 0; i < col; i++) { 

for (int j = 0; j < row; j++) { 

arr[i][j] = sc.nextInt(); 
} 
} 
System.out.println("Before Transpose"); 

for (int i = 0; i < col; i++) { 

for (int j = 0; j < row; j++) { 

System.out.print(arr[i][j] + " "); 

} 

System.out.println(); 

} 
toTranspose(arr, col, row); 
} 
private static void toTranspose(int[][] arr, int col, int row) { 

int a[][] = new int[row][col]; 

for (int i = 0; i < col; i++) { 

for (int j = 0; j < row; j++) { 

a[j][i] = arr[i][j]; 

} 

} 

System.out.println("After Transpose"); 

for (int i = 0; i < col; i++) { 

for (int j = 0; j < row; j++) { 

System.out.print(a[i][j] + " "); 

} 

System.out.println(); 

} 

} 

} 

 