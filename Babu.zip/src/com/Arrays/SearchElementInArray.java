package com.Arrays;

import java.util.Scanner;

public class SearchElementInArray
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int length=sc.nextInt();
		int a[]=new int[length];
		for(int i=0;i<a.length;i++) {
		  a[i]=sc.nextInt();
		}
		int search_element=50;
		boolean status=false;
        for(int x:a)
		{
			if(x==search_element)
			{
				System.out.println("element found");
				status=true;
			}
		}
		if(status==false)
		System.out.println("element not found");
//		int a[]= {10,20,30,40,50};
//		for(int i=0;i<a.length;i++)
//		{
//			if(a[i]==search_element)
//			{
//				System.out.println("element found");
//				break;//if the element found means no need to go for another iteration,that's why we keep this break
//			}
//			
//				
//		}
	}

}
