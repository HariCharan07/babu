package com.Arrays;
import java.util.Arrays;
import java.util.Scanner;

public class printDuplicateValues {  
public static void main(String[] args) {  
        
	Scanner sc=new Scanner(System.in);
	System.out.println("enter size");
	int length=sc.nextInt();
	int a[]=new int[length];
	for(int i=0;i<a.length;i++)
	{
		a[i]=sc.nextInt();
	}
	Arrays.sort(a);
         System.out.println("Duplicate elements in given array: ");  
         for(int i = 0; i < a.length; i++) {  
            for(int j = i + 1; j < a.length; j++) {  
                if(a[i] == a[j])  
                    System.out.println(a[j]);  
            }  
        }  
    }  
}  