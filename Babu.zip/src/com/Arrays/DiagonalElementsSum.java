package com.Arrays; 

import java.util.Scanner; 

public class DiagonalElementsSum { 

public static void main(String[] args) { 

Scanner sc = new Scanner(System.in); 

System.out.println("Enter No of Columns"); 

int col = sc.nextInt(); 

System.out.println("Enter No of Rows"); 

int row = sc.nextInt(); 

System.out.println("Enter values"); 

int arr[][] = new int[col][row]; 

for (int i = 0; i < col; i++) { 

for (int j = 0; j < row; j++) { 

arr[i][j] = sc.nextInt(); 

} 

} 
System.out.println("The Sums are : "); 
int psum = 0, ssum = 0; 
for (int i = 0; i < col; i++) { 
for (int j = 0; j < row; j++) { 
if (i == j) { 
psum = psum+arr[i][j]; 

} 

if (i + j == row-1) { 

ssum = ssum+arr[i][j]; 

} 

} 

} 

System.out.println("Principal Diagonal : "+psum); 

System.out.println("Principal Diagonal : "+ssum);		 

} 

} 
