package com.Arrays; 

import java.util.HashMap; 

import java.util.Map; 

import java.util.Scanner; 

import java.util.TreeMap; 

public class ArraySortMatrix { 

public static void main(String[] args) { 

Scanner sc = new Scanner(System.in); 

System.out.println("Enter Columns : "); 

int col = sc.nextInt(); 

System.out.println("Enter Rows : "); 

int row = sc.nextInt(); 

int[][] arr = new int[col][row]; 

System.out.println("Enter Numbers : "); 

for (int i = 0; i < arr.length; i++) { 

for (int j = 0; j < arr.length; j++) { 

arr[i][j] = sc.nextInt(); 

} 

} 

Map<Integer, Integer> map = new HashMap<>(); 

for (int i = 0; i < arr.length; i++) { 

int sum = 0; 

for (int j = 0; j < arr.length; j++) { 

sum = sum + arr[i][j]; 

} 

map.put(sum, i); 

} 

Map<Integer, Integer> sortbyKey = new TreeMap<>(map); 

for (Integer index : sortbyKey.values()) { 

for (int i = 0; i < arr.length; i++) { 

System.out.print(arr[index][i] + "  "); 

} 

System.out.println(); 

} 

} 

} 

 