package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class removeDuplicateElements 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size");
		int length=sc.nextInt();
		int a[]=new int[length];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		Arrays.sort(a);
		int j=0;
		for(int i=0;i<a.length-1;i++)
		{
			if(a[i]!=a[i+1])
			{
				a[j++]=a[i];
			}//5 2 2 4 7 7
		}
		a[j++]=a[a.length-1];
		for(int k=0;k<j;k++)
		{
			System.out.println(a[k]);
		}
		
	}

}
