package com.Arrays;

import java.util.Arrays;

public class findHowManyDuplicatesinArray 
{
	public static void main(String[] args) {
		int a[]= {100,200,100,300,100,400,200};
		System.out.println(Arrays.toString(a));
		int num=100;
		int count=0;
		for(int value:a)
		{
			if(value==num)
				count++;
		}
		System.out.println(count);
	}

}
