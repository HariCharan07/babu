package com.Arrays;

public class sumOfElements
{
	public static void main(String[] args) {
		int a[]= {2,4,5,6,1,7,9};
		
	}

}
