package com.Arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class descArray {
 
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length of Array : ");
		int num=sc.nextInt();
		Integer []a=new Integer[num];
		for(int i=0;i<a.length;i++){
			 a[i]=sc.nextInt();			
		}
		
		Arrays.sort(a,Collections.reverseOrder());
		for (Integer integer : a) {
			System.out.print(integer+" ");
		}	
	}
 
}