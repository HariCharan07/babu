package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class largestElement 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size");
		int length=sc.nextInt();
		int a[]=new int[length];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		Arrays.sort(a);
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println(a[a.length-1]);
		
	}

}
