package Practisecodes;

import java.util.Arrays;

public class sortString
{
	public static void main(String[] args) {
		String s="sudha";
		char[] ch=s.toCharArray();
		Arrays.sort(ch);
		System.out.println(new String(ch));
		
		
		
	}

}
