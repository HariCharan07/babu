package Practisecodes;

public class removeDuplicatesInString
{
	public static void main(String[] args) {
		String s="siddu";
		String temp="";
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(!temp.contains(ch+""))
		    {
				temp=temp+ch;
		    }
		}
		System.out.println(temp);
	}

}
