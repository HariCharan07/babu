package Practisecodes;

public class evenWords
{
	public static void main(String[] args) {
		String s="hi world java";
		String str[]=s.split(" ");
		for(String str1:str)
		{
			if(str1.length()%2==0)
			{
				System.out.println(str1);
			}
		}
	}

}
