package Practisecodes;

import java.util.Scanner;

public class DiagonalSumElements
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter columns");
		int col=sc.nextInt();
		System.out.println("enter rows");
		int rows=sc.nextInt();
		int a[][]=new int[col][rows];
		System.out.println("enter elements");
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<rows;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		int psum=0,ssum=0;
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<rows;j++)
			{
				if(i==j)
				{
					psum=psum+a[i][j];
				}
				if(i+j==rows-1)
				{
					ssum=ssum+a[i][j];
				}
			}
		}
		System.out.println(psum);
		System.out.println(ssum);
	}

}
