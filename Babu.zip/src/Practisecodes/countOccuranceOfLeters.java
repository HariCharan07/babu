package Practisecodes;

public class countOccuranceOfLeters 
{

	public static void main(String[] args) {
		String s1="mujjua";
		String s2="";
		while(s1.length()>0)
		{
			char ch=s1.charAt(0);
			s2=s1.replace(ch+"", "");
			//System.out.println(s2);
			int count=s1.length()-s2.length();
			System.out.println(ch+"="+count);
			s1=s2;
			
		}
		
	}
}
