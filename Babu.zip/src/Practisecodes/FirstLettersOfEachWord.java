package Practisecodes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FirstLettersOfEachWord
{
	public static void main(String[] args) {
		String s="greek for greek";
		Pattern p=Pattern.compile("\\b[a-zA-Z]");
		Matcher m=p.matcher(s);
		while(m.find())
		{
			System.out.print(m.group());
		}
	}

}
