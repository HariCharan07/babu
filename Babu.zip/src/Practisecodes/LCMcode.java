package Practisecodes;

public class LCMcode
{
	public static void main(String[] args) {
		int num1=15;
		int num2=25;
		int max=(num1>num2)?num1:num2;
		int lcm=max;
		while(true)
		{
			if(lcm%num1==0&&lcm%num2==0)
			{
				System.out.println(lcm);
				break;
			}
			lcm++;
		}
	}

}
