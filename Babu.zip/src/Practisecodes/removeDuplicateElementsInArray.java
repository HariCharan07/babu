package Practisecodes;

import java.util.Arrays;
import java.util.Scanner;

public class removeDuplicateElementsInArray
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int length=sc.nextInt();
		int a[]=new int[length];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		Arrays.sort(a);
		int j=0;
		for(int i=0;i<a.length-1;i++)
		{
			if(a[i]!=a[i+1])
				a[j++]=a[i];
		}
		a[j++]=a[a.length-1];
		for(int k=0;k<j;k++)
		{
			System.out.println(a[k]);
		}
		
	}

}
