package Practisecodes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class PangramChecker
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter String");
		String s=sc.nextLine();
		if(ispanagram(s))
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}
		
	}
	public static boolean ispanagram(String str)
	{
		str=str.toLowerCase();
		HashSet<Character> letters=new HashSet<>();
		for(char ch:str.toCharArray())
		{
			if(ch>='a'&&ch<='z')
			{
				letters.add(ch);
			}
		}
		
		
		return letters.size()==26;
	}
	

}
