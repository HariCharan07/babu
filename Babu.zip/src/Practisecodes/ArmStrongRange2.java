package Practisecodes;

public class ArmStrongRange2 
{
	public static void main(String[] args) {
		int num1=100;
		int num2=200;
		for(int i=num1;i<=num2;i++)
		{
			int n=i,count=0;
			while(n>0)
			{
				int rem=n%10;
				count++;
				n=n/10;
			}
			int n1=i,result=0;
			while(n1>0)
			{
				int rem1=n1%10;
				result=result+(int)Math.pow(rem1, count);
				n1=n1/10;
		    }
			if(result==i) {
				System.out.println(result);
			}
			
		}
		
		
	
}

}
