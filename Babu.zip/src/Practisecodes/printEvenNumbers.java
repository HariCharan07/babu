package Practisecodes;

import java.util.Scanner;

public class printEvenNumbers
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//String s="hi java welcome to world";
		String str=sc.nextLine();
		String str1[]=str.split("");
		
		
		
	}

}
