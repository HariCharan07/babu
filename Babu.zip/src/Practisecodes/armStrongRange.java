package Practisecodes;

import java.util.Scanner;

public class armStrongRange 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		for(int i=num1;i<=num2;i++)
		{
			int n=i,count=0;
			while(n>0)
			{
				int rem=n%10;
				count++;
				n=n/10;
			}
			int n1=i,sum=0;
			while(n1>0)
			{
				int rem1=n1%10;
				sum=sum+(int)Math.pow(rem1, count);
				n1=n1/10;
			}
			if(sum==i)
			{
				System.out.println(sum);
			}
		}
		
	}

}
