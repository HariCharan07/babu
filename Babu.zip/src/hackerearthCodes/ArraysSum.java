package hackerearthCodes;

import java.util.Scanner;

public class ArraysSum 
{
	    public static void main(String args[] )  {
	        Scanner sc=new Scanner(System.in);
	        int length= sc.nextInt();
	        long a[]=new long[length];
	        for(int i=0;i<a.length;i++)
	        {
	            a[i]=sc.nextInt();
	        }
	        long sum=0;
	        for(int i=0;i<a.length;i++)
	        {
	               sum=sum+a[i];
	        }
	        System.out.println(sum);
	    }
	}



