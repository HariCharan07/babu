package hackerearthCodes;
import java.util.Scanner;

public class ProductOfArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read the size of the array
        int N = sc.nextInt();
        long product = 1; // Use long to handle large products
        final int MOD = 1000000007; // Modulo value
        
        // Read the elements and compute the product
        for (int i = 0; i < N; i++) {
            int number = sc.nextInt();
            product = (product * number) % MOD; // Update product with modulo
        }
        
        // Output the result
        System.out.println(product);
        
        sc.close();
    }
}
