package hackerearthCodes;
import java.util.Scanner;

public class DivisibilityByThree {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read the size of the array
        int n = sc.nextInt();
        int sum = 0;
        
        // Read the integers and calculate the sum of their last digits
        for (int i = 0; i < n; i++) {
            int number = sc.nextInt();
            sum =sum*10+ number % 10; // Get the last digit
        }
        
        // Check if the sum of the last digits is divisible by 3
        if (sum % 10 == 0) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }
         System.out.println(sum);
    }
}
