package hackerearthCodes;
import java.util.Scanner;

public class MissingEvenNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt(); // Number of test cases

        while (T-- > 0) {
            int N = sc.nextInt(); // Size of the array
            boolean[] isEvenPresent = new boolean[100]; // Track even numbers (0 to 98)

            for (int i = 0; i < N; i++) {
                int num = sc.nextInt();
                if (num > 0 && num % 2 == 0) {
                    isEvenPresent[num] = true; // Mark the even number as present
                }
            }

            // Find the maximum missing even number
            int maxMissingEven = 0;
            for (int i = 0; i < isEvenPresent.length; i += 2) {
                if (!isEvenPresent[i]) {
                    maxMissingEven = i; // Update max missing even number
                }
            }

            // The next even number after the maximum missing one
            System.out.println(maxMissingEven + 2);
        }

        sc.close();
    }
}
