package hackerearthCodes;
import java.util.HashMap;
import java.util.Scanner;

public class FavoriteSingers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         // Read the number of songs
        long n = sc.nextLong(); 
        
        // HashMap to count occurrences of each singer
        HashMap<Long, Long> singerCount = new HashMap<>();
        
        // Read the singer IDs and count them
        for (long i = 0; i < n; i++) {
            long singer = sc.nextLong();
            singerCount.put(singer, singerCount.getOrDefault(singer, 0L) + 1);
        }
        
        // Find the maximum count of songs
        long maxCount = 0;
        for (long count : singerCount.values()) {
            if (count > maxCount) {
                maxCount = count;
            }
        }
        
        // Count how many singers have the maximum count
        long favoriteSingersCount = 0;
        for (long count : singerCount.values()) {
            if (count == maxCount) {
                favoriteSingersCount++;
            }
        }
        System.out.println(favoriteSingersCount);
        
    }
}
